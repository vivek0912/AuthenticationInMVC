﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCCustomAuth.Models
{
    public class Repository
    {
        public static List<User> users = new List<User>() {
        new User() {UserId=101, Username="admin123",Email="admin@test.com",Roles="Admin",Password="admin",FirstName="Admin",LastName="Admin" },
        new User() {UserId=102, Username="user123",Email="user@test.com",Roles="User",Password="user",FirstName="User",LastName="User" }
    };

        //public static User GetUserDetails(User user)
        //{
        //    return users.Where(u => u.Email.ToLower() == user.Email.ToLower() &&
        //    u.Password == user.Password).FirstOrDefault();
        //}
    }
}